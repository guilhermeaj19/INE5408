//! Copyright [2023] <Guilherme Adenilson de Jesus>
#ifndef STRUCTURES_DOUBLY_CIRCULAR_LIST_H
#define STRUCTURES_DOUBLY_CIRCULAR_LIST_H

#include <cstdint>

namespace structures {

template<typename T>
class DoublyCircularList {
 public:
    DoublyCircularList();
    ~DoublyCircularList();

    void clear();

    void push_back(const T& data);  // insere no fim
    void push_front(const T& data);  // insere no início
    void insert(const T& data, std::size_t index);  // insere na posição
    void insert_sorted(const T& data);  // insere em ordem

    T pop(std::size_t index);  // retira da posição
    T pop_back();  // retira do fim
    T pop_front();  // retira do início
    void remove(const T& data);  // retira específico

    bool empty() const;  // lista vazia
    bool contains(const T& data) const;  // contém

    T& at(std::size_t index);  // acesso a um elemento (checando limites)
    const T& at(std::size_t index) const;  // getter constante a um elemento

    std::size_t find(const T& data) const;  // posição de um dado
    std::size_t size() const;  // tamanho

 private:
    class Node {  // Elemento
     public:
        explicit Node(const T& data):
            data_{data}
        {}
        Node(const T& data, Node* next, Node* previous):
            data_{data},
            next_{next},
            previous_{previous}
        {}
        T& data() {  // getter: dado
            return data_;
        }
        const T& data() const {  // getter const: dado
            return data_;
        }
        Node* next() {  // getter: próximo
            return next_;
        }
        const Node* next() const {  // getter const: próximo
            return next_;
        }
        void next(Node* node) {  // setter: próximo
            next_ = node;
        }
        Node* previous() {  // getter: previous
            return previous_;
        }
        const Node* previous() const {  // getter const: previous
            return previous_;
        }
        void previous(Node* node) {  // setter: previous
            previous_ = node;
        }

     private:
        T data_;
        Node* next_{nullptr};
        Node* previous_{nullptr};
    };
    Node* Position(size_t index) {
        Node* p;
        if (index < (size()/2)) {
            p = head->next();
            for (size_t i = 0; i < index; i++) {
                p = p->next();
            }
        } else {
            p = head->previous();
            for (size_t i = size() - 1; i > index; i--) {
                p = p->previous();
            }
        }
        return p;
    }
    Node* head;
    std::size_t size_;
};

}  // namespace structures

#endif

template<typename T>
structures::DoublyCircularList<T>::DoublyCircularList() {
    T data;
    head = new Node(data);
    size_ = 0;
}

template<typename T>
structures::DoublyCircularList<T>::~DoublyCircularList() {
    clear();
    delete head;
}

template<typename T>
void structures::DoublyCircularList<T>::clear() {
    while (!empty()) {
        pop_back();
    }
    size_ = 0;
}

template<typename T>
void structures::DoublyCircularList<T>::insert(const T& dt, std::size_t idx) {
    if (idx == 0) {
        return push_front(dt);
    }
    if (idx == size_) {
        return push_back(dt);
    }
    if (idx < 0 || idx > size_) {
        throw std::out_of_range("index menor que zero ou maior que size");
    }
    Node * novo = new Node(dt);
    if (novo == nullptr) {
        throw std::out_of_range("nullptr");
    }
    Node *p = Position(idx);
    novo->next(p);
    novo->previous(p->previous());
    p->previous()->next(novo);
    p->previous(novo);
    size_++;
}

template<typename T>
void structures::DoublyCircularList<T>::push_back(const T& data) {
    Node *novo = new Node(data);
    if (novo == nullptr) {
        throw std::out_of_range("nullptr");
    }
    if (empty()) {
        head->next(novo);
    } else {
        head->previous()->next(novo);
    }
    novo->previous(head->previous());
    head->previous(novo);
    size_++;
}

template<typename T>
void structures::DoublyCircularList<T>::push_front(const T& data) {
    Node *novo = new Node(data);
    if (novo == nullptr) {
        throw std::out_of_range("nullptr");
    }
    if (empty()) {
        head->previous(novo);
    } else {
        head->next()->previous(novo);
    }
    novo->next(head->next());
    head->next(novo);
    size_++;
    }


template<typename T>
void structures::DoublyCircularList<T>::insert_sorted(const T& data) {
    Node *p = head->next();
    size_t i = 0;
    while (p != head && i < size_) {
        if (p->data() > data) {
            break;
        }
        i++;
        p = p->next();
    }
    insert(data, i);
}

template<typename T>
T structures::DoublyCircularList<T>::pop(std::size_t index) {
    if (empty() || index < 0 || index >= size_) {
        throw std::out_of_range("lista vazia");
    }
    if (index == 0) {
        return pop_front();
    }
    if (index == size_ - 1) {
        return pop_back();
    }

    Node *aux = Position(index);
    aux->previous()->next(aux->next());
    aux->next()->previous(aux->previous());
    T resp = aux->data();
    delete aux;
    size_--;
    return resp;
}

template<typename T>
T structures::DoublyCircularList<T>::pop_back() {
    if (empty()) {
        throw std::out_of_range("vazia");
    }
    Node *aux = head->previous();
    head->previous(aux->previous());
    T resp = aux->data();
    delete aux;
    size_--;
    return resp;
}

template<typename T>
T structures::DoublyCircularList<T>::pop_front() {
    if (empty()) {
        throw std::out_of_range("vazia");
    }
    Node *aux = head->next();
    head->next(aux->next());
    T resp = aux->data();
    delete aux;
    size_--;
    return resp;
}

template<typename T>
void structures::DoublyCircularList<T>::remove(const T& data) {
    Node *p = head->next();
    if (p->data() == data) {
        pop_front();
        return;
    }
    for (size_t i = 1; p != head && i < size_; i++) {
        p = p->next();
        if (p->data() == data) {
            pop(i);
            return;
        }
    }
}

template<typename T>
bool structures::DoublyCircularList<T>::empty() const {
    return (size_ == 0);
}

template<typename T>
bool structures::DoublyCircularList<T>::contains(const T& data) const {
    Node *p = head->next();
    if (p->data() == data) {
        return true;
    }
    for (size_t i = 1; p != head && i < size_; i++) {
        p = p->next();
        if (p->data() == data) {
            return true;
        }
    }
    return false;
}

template<typename T>
std::size_t structures::DoublyCircularList<T>::find(const T& data) const {
    Node *p = head->next();
    if (p->data() == data) {
        return 0;
    }
    for (size_t i = 1; p != head && i < size_; i++) {
        p = p->next();
        if (p->data() == data) {
            return i;
        }
    }
    return size_;
}

template<typename T>
std::size_t structures::DoublyCircularList<T>::size() const {
    return size_;
}

template<typename T>
T& structures::DoublyCircularList<T>::at(std::size_t index) {
    if (index < 0 || index >= size_) {
        throw std::out_of_range("index maior que o tamanho da lista");
    }

    Node *p = Position(index);
    return p->data();
}

