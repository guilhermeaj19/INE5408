//! Copyright [2023] <Guilherme Adenilson de Jesus>
#ifndef STRUCTURES_CIRCULAR_LIST_H
#define STRUCTURES_CIRCULAR_LIST_H

#include <cstdint>


namespace structures {

template<typename T>
class CircularList {
 public:
    CircularList();
    ~CircularList();

    void clear();  // limpar lista

    void push_back(const T& data);  // inserir no fim
    void push_front(const T& data);  // inserir no início
    void insert(const T& data, std::size_t index);  // inserir na posição
    void insert_sorted(const T& data);  // inserir em ordem

    T& at(std::size_t index);  // acessar em um indice (com checagem de limites)
    const T& at(std::size_t index) const;  // versão const do acesso ao indice

    T pop(std::size_t index);  // retirar da posição
    T pop_back();  // retirar do fim
    T pop_front();  // retirar do início
    void remove(const T& data);  // remover dado específico

    bool empty() const;  // lista vazia
    bool contains(const T& data) const;  // lista contém determinado dado?
    std::size_t find(const T& data) const;  // posição de um item na lista

    std::size_t size() const;  // tamanho da lista

 private:
    class Node {  // Elemento
     public:
        explicit Node(const T& data):
            data_{data}
        {}
        Node(const T& data, Node* next, Node* previous):
            data_{data},
            next_{next},
            previous_{previous}
        {}
        T& data() {  // getter: dado
            return data_;
        }
        const T& data() const {  // getter const: dado
            return data_;
        }
        Node* next() {  // getter: próximo
            return next_;
        }
        const Node* next() const {  // getter const: próximo
            return next_;
        }
        void next(Node* node) {  // setter: próximo
            next_ = node;
        }
        Node* previous() {  // getter: previous
            return previous_;
        }
        const Node* previous() const {  // getter const: previous
            return previous_;
        }
        void previous(Node* node) {  // setter: previous
            previous_ = node;
        }

     private:
        T data_;
        Node* next_{nullptr};
        Node* previous_{nullptr};
    };
    Node* Position(size_t index) {
        Node* p;
        if (index < (size()/2)) {
            p = head->next();
            for (size_t i = 0; i < index; i++) {
                p = p->next();
            }
        } else {
            p = head->previous();
            for (size_t i = size() - 1; i > index; i--) {
                p = p->previous();
            }
        }
        return p;
    }
    Node* head;
    std::size_t size_;
};

}  //  namespace structures

#endif

template<typename T>
structures::CircularList<T>::CircularList() {
    T data;
    head = new Node(data);
    size_ = 0;
}

template<typename T>
structures::CircularList<T>::~CircularList() {
    clear();
    delete head;
}

template<typename T>
void structures::CircularList<T>::clear() {
    while (!empty()) {
        pop_back();
    }
    size_ = 0;
}

template<typename T>
void structures::CircularList<T>::insert(const T& dt, std::size_t idx) {
    if (idx == 0) {
        return push_front(dt);
    }
    if (idx == size_) {
        return push_back(dt);
    }
    if (idx < 0 || idx > size_) {
        throw std::out_of_range("index menor que zero ou maior que size");
    }
    Node * novo = new Node(dt);
    if (novo == nullptr) {
        throw std::out_of_range("nullptr");
    }
    Node *p = Position(idx);
    novo->next(p);
    novo->previous(p->previous());
    p->previous()->next(novo);
    p->previous(novo);
    size_++;
}

template<typename T>
void structures::CircularList<T>::push_back(const T& data) {
    Node *novo = new Node(data);
    if (novo == nullptr) {
        throw std::out_of_range("nullptr");
    }
    if (empty()) {
        head->next(novo);
    } else {
        head->previous()->next(novo);
    }
    novo->previous(head->previous());
    head->previous(novo);
    size_++;
}

template<typename T>
void structures::CircularList<T>::push_front(const T& data) {
    Node *novo = new Node(data);
    if (novo == nullptr) {
        throw std::out_of_range("nullptr");
    }
    if (empty()) {
        head->previous(novo);
    } else {
        head->next()->previous(novo);
    }
    novo->next(head->next());
    head->next(novo);
    size_++;
    }


template<typename T>
void structures::CircularList<T>::insert_sorted(const T& data) {
    Node *p = head->next();
    size_t i = 0;
    while (p != head && i < size_) {
        if (p->data() > data) {
            break;
        }
        i++;
        p = p->next();
    }
    insert(data, i);
}

template<typename T>
T structures::CircularList<T>::pop(std::size_t index) {
    if (empty() || index < 0 || index >= size_) {
        throw std::out_of_range("lista vazia");
    }
    if (index == 0) {
        return pop_front();
    }
    if (index == size_ - 1) {
        return pop_back();
    }

    Node *aux = Position(index);
    aux->previous()->next(aux->next());
    aux->next()->previous(aux->previous());
    T resp = aux->data();
    delete aux;
    size_--;
    return resp;
}

template<typename T>
T structures::CircularList<T>::pop_back() {
    if (empty()) {
        throw std::out_of_range("vazia");
    }
    Node *aux = head->previous();
    head->previous(aux->previous());
    T resp = aux->data();
    delete aux;
    size_--;
    return resp;
}

template<typename T>
T structures::CircularList<T>::pop_front() {
    if (empty()) {
        throw std::out_of_range("vazia");
    }
    Node *aux = head->next();
    head->next(aux->next());
    T resp = aux->data();
    delete aux;
    size_--;
    return resp;
}

template<typename T>
void structures::CircularList<T>::remove(const T& data) {
    Node *p = head->next();
    if (p->data() == data) {
        pop_front();
        return;
    }
    for (size_t i = 1; p != head && i < size_; i++) {
        p = p->next();
        if (p->data() == data) {
            pop(i);
            return;
        }
    }
}

template<typename T>
bool structures::CircularList<T>::empty() const {
    return (size_ == 0);
}

template<typename T>
bool structures::CircularList<T>::contains(const T& data) const {
    Node *p = head->next();
    if (p->data() == data) {
        return true;
    }
    for (size_t i = 1; p != head && i < size_; i++) {
        p = p->next();
        if (p->data() == data) {
            return true;
        }
    }
    return false;
}

template<typename T>
std::size_t structures::CircularList<T>::find(const T& data) const {
    Node *p = head->next();
    if (p->data() == data) {
        return 0;
    }
    for (size_t i = 1; p != head && i < size_; i++) {
        p = p->next();
        if (p->data() == data) {
            return i;
        }
    }
    return size_;
}

template<typename T>
std::size_t structures::CircularList<T>::size() const {
    return size_;
}

template<typename T>
T& structures::CircularList<T>::at(std::size_t index) {
    if (index < 0 || index >= size_) {
        throw std::out_of_range("index maior que o tamanho da lista");
    }

    Node *p = Position(index);
    return p->data();
}


