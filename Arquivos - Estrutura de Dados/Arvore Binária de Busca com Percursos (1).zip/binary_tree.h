// Copyright [2019] <Guilherme Adenilson de Jesus>
#include "array_list.h"

#ifndef STRUCTURES_BINARY_TREE_H
#define STRUCTURES_BINARY_TREE_H

#include <cstdint>

namespace structures {

template<typename T>
class BinaryTree {
public:
    ~BinaryTree();

    void insert(const T& data);

    void remove(const T& data);

    bool contains(const T& data) const;

    bool empty() const;

    std::size_t size() const;

    ArrayList<T> pre_order() const;

    ArrayList<T> in_order() const;

    ArrayList<T> post_order() const;

private:
    struct Node {
        explicit Node(const T& data):
            data{data}
        {}
        T data;
        Node* left{nullptr};
        Node* right{nullptr};
        void insert(const T& data_) {
            Node *novo;
            if (data_ < this->data) {
                if (this->left == nullptr) {
                    novo = new Node(data_);
                    this->left = novo;
                } else {
                    this->left->insert(data_);
                }
            } else {
                if (this->right == nullptr) {
                    novo = new Node(data_);
                    this->right = novo;
                } else {
                    this->right->insert(data_);
                }
            }
        }

        bool remove(const T& data) {
            bool deleted = false;
            if (data < this->data && this->left != nullptr) {
                this->left = remove(data, this->left, deleted);
            } else if (data > this->data && this->right != nullptr) {
                this->right = remove(data, this->right, deleted);
            } else {
                if (this->right != nullptr && this->left != nullptr) {
                    Node* temp = this->right->minimum();
                    this->data = temp->data;
                    this->right = remove(this->data, this->right, deleted);
                } else if (this->right != nullptr) {
                    Node* temp = this->right;
                    this->data = temp->data;
                    this->right = temp->right;
                    this->left = temp->left;
                    temp->right = temp->left = nullptr;
                    delete temp;
                    deleted = true;
                } else if (this->left != nullptr) {
                    Node* temp = this->left;
                    this->data = temp->data;
                    this->right = temp->right;
                    this->left = temp->left;
                    temp->right = temp->left = nullptr;
                    delete temp;
                    deleted = true;
                }
            }
            return deleted;
        }

        bool contains(const T& data_) const {
            if (this->data == data_) return true;
            if (data_ < this->data && this->left != nullptr) {
                return this->left->contains(data_);
            } else {
                if (data_ > this->data && this->right != nullptr) {
                    return this->right->contains(data_);
                }
            }
            return false;
        }

        void pre_order(ArrayList<T>& v) const {
            v.push_back(this->data);
            if (this->left != nullptr) this->left->pre_order(v);
            if (this->right != nullptr) this->right->pre_order(v);
        }

        void in_order(ArrayList<T>& v) const {
            if (this->left != nullptr) this->left->in_order(v);
            v.push_back(this->data);
            if (this->right != nullptr) this->right->in_order(v);
        }

        void post_order(ArrayList<T>& v) const {
            if (this->left != nullptr) this->left->post_order(v);
            if (this->right != nullptr) this->right->post_order(v);
            v.push_back(this->data);
        }

     private:
        Node* remove(const T& data, Node* arv, bool& deleted) {
            deleted = false;
            if (arv == nullptr)
                return arv;
            if (data < arv->data) {
                arv->left = remove(data, arv->left, deleted);
                return arv;
            }
            if (data > arv->data) {
                arv->right = remove(data, arv->right, deleted);
                return arv;
            }
            if (arv->right != nullptr && arv->left != nullptr) {
                Node* temp = arv->right->minimum();
                arv->data = temp->data;
                arv->right = remove(data, arv->right, deleted);
                return arv;
            }
            Node* temp = nullptr;
            if (arv->right != nullptr)
                temp = arv->right;
            else
                temp = arv->left;

            arv->right = arv->left = nullptr;
            delete arv;
            deleted = true;
            return temp;
        }

        Node* minimum() {
            if (this->left == nullptr)
                return this;
            return this->left->minimum();
        }
    };

    Node* root;
    std::size_t size_ = 0;
};

}  // namespace structures

#endif

template<typename T>
structures::BinaryTree<T>::~BinaryTree() {
    while (root != nullptr) remove(root->data);
    size_ = 0;
}


template<typename T>
void structures::BinaryTree<T>::insert(const T& data) {
    if (root != nullptr) {
        root->insert(data);

    } else {
        root = new Node(data);
        if (root == nullptr) {
            throw std::out_of_range("Full tree!");
        }
    }
    size_++;
}

template<typename T>
void structures::BinaryTree<T>::remove(const T& data) {
    if (empty()) throw std::out_of_range("Empty tree!");
    if (root->data == data && size_ == 1u) {
        delete root;
        root = nullptr;
        size_--;
    }
    if (root != nullptr) {
        if (root->remove(data)) {
            size_--;
        }
    }
}

template<typename T>
bool structures::BinaryTree<T>::contains(const T& data) const {
    if (root != nullptr) {
        return root->contains(data);
    }
    return false;
}

template<typename T>
bool structures::BinaryTree<T>::empty() const {
    return (size_ == 0);
}

template<typename T>
std::size_t structures::BinaryTree<T>::size() const {
    return size_;
}

template<typename T>
structures::ArrayList<T> structures::BinaryTree<T>::pre_order() const {
    structures::ArrayList<T> list{size()};
    if (root != nullptr) {
        root->pre_order(list);
    }
    return list;
}

template<typename T>
structures::ArrayList<T> structures::BinaryTree<T>::in_order() const {
    structures::ArrayList<T> list{size()};
    if (root != nullptr) {
        root->in_order(list);
    }
    return list;
}

template<typename T>
structures::ArrayList<T> structures::BinaryTree<T>::post_order() const {
    structures::ArrayList<T> list{size()};
    if (root != nullptr) {
        root->post_order(list);
    }
    return list;
}
