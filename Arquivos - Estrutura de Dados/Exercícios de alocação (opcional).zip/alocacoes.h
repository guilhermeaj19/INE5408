// Copyright [2022] <COLOQUE SEU NOME AQUI...>
#include <string>


class Aluno {
 public:
    Aluno() {}  // construtor
    ~Aluno() {}  // destrutor
    std::string devolveNome() {
        return nome;
    }
    int devolveMatricula() {
        return matricula;
    }
    void escreveNome(std::string nome_) {
        nome = nome_;
    }
    void escreveMatricula(int matricula_) {
        matricula = matricula_;
    }
 private:
    std::string nome;
    int matricula;
};


Aluno *turma_filtra(Aluno t[], int N, int menor_matr) {
    Aluno *tf;

    int qtd_alunos_menor = 0;
    for (int i = 0; i < N; i++) {
        if (t[i].devolveMatricula() >= menor_matr) {
            qtd_alunos_menor += 1;
        }
    }
    tf = new Aluno[qtd_alunos_menor];
    for (int i = 0; i < qtd_alunos_menor; i++) {
        tf[i].escreveMatricula(-1);
    }
    for (int i = 0; i < N; i++) {
        if (t[i].devolveMatricula() >= menor_matr) {
            for (int j = 0; j < qtd_alunos_menor; j++) {
                if (tf[j].devolveMatricula() == -1) {
                    tf[j] = t[i];
                    break;
                }
            }
        }
    }

    return tf;
}

int *turma_conta(Aluno t[], int N) {
    int *c;
    c = new int[26];
    for (int i = 0; i < 26; i++) {
        c[i] = 0;
    }

    for (int i = 0; i < N; i++) {
        char car = t[i].devolveNome()[0];
        c[car - 'A'] += 1;
    }
    return c;
}

/*
    *** Importante ***

    A função 'main()' não deve ser escrita aqui, pois é parte do código dos testes e já está implementada

*/
