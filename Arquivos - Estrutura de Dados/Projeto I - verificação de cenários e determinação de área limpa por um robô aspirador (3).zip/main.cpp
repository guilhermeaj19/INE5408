//Aluno: Guilherme Adenilson de Jesus

#include <iostream>
#include <fstream>
#include "array_stack.h"
#include "array_queue.h"

using namespace std;

typedef struct Coordenadas
{
    int x;
    int y;
} Coordenadas;

typedef struct Cenario
{
    string nome;
    int altura;
    int largura;
    string matriz;
    Coordenadas posicao_inicial;
} Cenario;

string xml_to_string(string xmlfilename)
{
    string text;
    string line;
    
    ifstream file(xmlfilename);
    
    if (file.is_open()) {
    while (getline(file,line))
    {
      text += line;
    }
    file.close();
    }
    else cout << "Não foi possível abrir o arquivo" << endl;
    
    return text;
}

bool validacao_XML(string text)
{
    int tamanho = text.size();
    structures::ArrayStack<string> pilha(tamanho);
    for (int i = 0; i < tamanho; i++) {
        string tmp;
        if (text[i] == '<' && text[i+1] == '/') {
            int j = i + 2;
            while (text[j] != '>') {
                tmp += text[j];
                j++;
            }
            if (pilha.empty() && (pilha.top() != tmp)) {
                return false;
            }
            pilha.pop();
            i = j;
        } else {
            if (text[i] == '<') {
            int j = i + 1;
            while (text[j] != '>') {
                tmp += text[j];
                j++;
            }
            pilha.push(tmp);
            i = j;
            }
        }
    }
    return pilha.empty();
}

Cenario* Criar_Cenarios(string text, int qtd_cenarios)
{   
    Cenario *cenarios;
    cenarios = new Cenario[qtd_cenarios];
    int pos, end_pos;
    
    for (int i = 0; i < qtd_cenarios; i++) {
        pos = text.find("<nome>") + 6;
        end_pos = text.find("</nome>");
        cenarios[i].nome = text.substr(pos, (end_pos - pos));
        
        pos = text.find("<altura>") + 8;
        end_pos = text.find("</altura>");
        cenarios[i].altura = atoi(text.substr(pos, (end_pos - pos)).c_str());

        pos = text.find("<largura>") + 9;
        end_pos = text.find("</largura>");
        cenarios[i].largura = atoi(text.substr(pos, (end_pos - pos)).c_str());
        
        pos = text.find("<matriz>") + 8;
        end_pos = text.find("</matriz>");
        cenarios[i].matriz = text.substr(pos, (end_pos - pos));
        
        pos = text.find("<x>") + 3;
        end_pos = text.find("</x>");
        cenarios[i].posicao_inicial.x = atoi(text.substr(pos, (end_pos - pos)).c_str());
        
        pos = text.find("<y>") + 3;
        end_pos = text.find("</y>");
        cenarios[i].posicao_inicial.y = atoi(text.substr(pos, (end_pos - pos)).c_str());

        pos = text.find("<cenario>");
        end_pos = text.find("</cenario>") + 10;
        text.erase(pos, (end_pos - pos));
    }
    return cenarios;
}

int Quantidade_de_Cenarios(string text)
{
    int qtd_cenarios = 0;
    int tamanho = text.size();
    for (int i = 0; i < tamanho; i++) {
        if (text[i] == '<') {
            string tmp;
            int j = i + 1;
            while (text[j] != '>') {
                if (text[j] != ' ') {tmp += text[j];}
                j++;
            }
            if (tmp == "cenario") qtd_cenarios++;
        }
    }
    return qtd_cenarios;
}

bool **matriz_booleana(string matriz, int altura, int largura)
{
    bool **matriz_booleana;
    matriz_booleana = new bool*[altura];
    for (int i = 0; i < altura; i++) matriz_booleana[i] = new bool[largura];
    
    for (int linha = 0; linha < altura; linha++) {
        for (int coluna = 0; coluna < largura; coluna++) {
            matriz_booleana[linha][coluna] = (matriz[linha*largura + coluna] == '1');
        }
    }
    return matriz_booleana;
}

int Area_Limpa_Pelo_Robo(Cenario cenario)
{   
    int area = 0;
    int altura = cenario.altura;
    int largura = cenario.largura;
    structures::ArrayQueue<Coordenadas> fila(altura*largura);
    
    bool **matriz = matriz_booleana(cenario.matriz, altura, largura);
    bool **R = new bool*[altura];
    for (int i = 0; i < altura; i++) R[i] = new bool[largura];

    for (int linha = 0; linha < altura; linha++) {
        for (int coluna = 0; coluna < largura; coluna++) {
            R[linha][coluna] = 0;
        }
    }
    
    if (matriz[cenario.posicao_inicial.x][cenario.posicao_inicial.y]) {
        fila.enqueue(cenario.posicao_inicial);
        R[cenario.posicao_inicial.x][cenario.posicao_inicial.y] = 1;
    }
    while (! fila.empty()) {
        Coordenadas posicao = fila.dequeue();
        Coordenadas posicao_vizinha;
        int x = posicao.x;
        int y = posicao.y;

        if (x - 1 >= 0) {
            if ((! R[x-1][y]) && matriz[x-1][y]) {
                posicao_vizinha = posicao;
                posicao_vizinha.x--;
                fila.enqueue(posicao_vizinha);
                R[x-1][y] = 1;
            }
        }
        if (x + 1 < altura) {
            if ((! R[x+1][y]) && matriz[x+1][y]) {
                posicao_vizinha = posicao;
                posicao_vizinha.x++;
                fila.enqueue(posicao_vizinha);
                R[x+1][y] = 1;
            }
        }
        if (y + 1 < largura) {
            if ((! R[x][y+1]) && matriz[x][y+1]) {
                posicao_vizinha = posicao;
                posicao_vizinha.y++;
                fila.enqueue(posicao_vizinha);
                R[x][y+1] = 1;
            }
        }
        if (y - 1 >= 0) {
            if ((! R[x][y-1]) && matriz[x][y-1]) {
                posicao_vizinha = posicao;
                posicao_vizinha.y--;
                fila.enqueue(posicao_vizinha);
                R[x][y-1] = 1;
            }
        }
    }
    
    for (int linha = 0; linha < altura; linha++) {
        for (int coluna = 0; coluna < largura; coluna++) {
            if (R[linha][coluna]) area++;
        }
    }

    for (int i = 0; i < altura; i++) {
        delete [] matriz[i];
    }
    delete [] matriz;
    for (int i = 0; i < altura; i++) {
        delete [] R[i];
    }
    delete [] R;
    return area;
}

int main()
{

    char xmlfilename[100];

    std::cin >> xmlfilename;  // entrada

    string text = xml_to_string(xmlfilename);
    
    if (validacao_XML(text)) {
        int area_limpa;
        int qtd_cenarios = Quantidade_de_Cenarios(text);
        Cenario *cenarios = Criar_Cenarios(text, qtd_cenarios);
        
        for (int i = 0; i < qtd_cenarios; i++) 
        {   
            area_limpa = Area_Limpa_Pelo_Robo(cenarios[i]);
            cout << cenarios[i].nome << ' ' << area_limpa << endl;
        }
        
        delete [] cenarios;
    } else cout << "erro" << endl;

    return 0;
}
