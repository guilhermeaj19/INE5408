// Copyright [2023] <COLOQUE SEU NOME AQUI...>

/*
    *** Importante ***

    O código de fila em vetor está disponível internamente (não precisa de implementação aqui)

*/



void retira_veiculo(structures::ArrayQueue<int> *f, int k) {
    for (int i = 0; i < k; i++) {
        int aux = f->dequeue();
        f->enqueue(aux);
    }
}


void mantenha_veiculo(structures::ArrayQueue<int> *f, int k) {
    int size = static_cast<int>(f->size());
    for (int i = 0; i < size; i++) {
        if (i == k - 1) {
            int aux = f->dequeue();
            f->enqueue(aux);
        } else {
            f->dequeue();
        }
    }
}



/*
    *** Importante ***

    A função 'main()' não deve ser escrita aqui, pois é parte do código dos testes e já está implementada

*/
