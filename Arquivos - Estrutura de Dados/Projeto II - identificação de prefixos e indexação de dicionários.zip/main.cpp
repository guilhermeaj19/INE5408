#include <iostream>
#include <fstream>
#include "trie_tree.h"

using namespace std;
using namespace structures;

TrieTree* criar_arvore(string filename) {
    
    TrieTree *arvore = new TrieTree;
    
    ifstream file(filename);
    string line;
    
    int posicao = 0;
    int i = 1;
    
    if (file.is_open()) {
        while (getline(file,line))
        {   
            string palavra;
            while (line[i] != ']') {
                palavra += line[i];
                i++;
            }
            
            int pos = posicao;
            int comprimento = line.size();
            
            arvore->insert_word(palavra, posicao, comprimento);
            posicao = pos + comprimento + 1;
            i = 1;
        }
        
    file.close();
    }
    else cout << "Não foi possível abrir o arquivo" << endl;

    return arvore;
};

void buscar_palavra(string palavra, structures::TrieTree* arvore) {
    int* dados;
    dados = arvore->find_word(palavra);
    
    if (dados[0] == 0) {
        cout << palavra << " is not prefix" << endl;
    } else {
        cout << palavra << " is prefix of " <<  dados[0] << " words" << endl;
        if (dados[2] > 0) {
            cout << palavra << " is at (" << dados[1] << ",";
            cout << dados[2] << ")" << endl;
        }
    }
    
    delete [] dados;
}


int main() {
    
    string filename;
    string word;

    cin >> filename;  // entrada

    TrieTree *arvore = criar_arvore(filename);
    
    if (arvore == nullptr) {
        return 0;
    }
    
    while (1) {  // leitura das palavras ate' encontrar "0"
        cin >> word;
        if (word.compare("0") == 0) {
            break;
        }
        buscar_palavra(word, arvore);
    }
    
    arvore->~TrieTree();
    return 0;
}
