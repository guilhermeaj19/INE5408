// Copyright [2019] <Guilherme Adenilson de Jesus>

#ifndef STRUCTURES_TRIE_TREE_H
#define STRUCTURES_TRIE_TREE_H

#include <cstdint>

using namespace std;

namespace structures {

class TrieTree {
public:
    TrieTree();
    ~TrieTree();
    
    void insert_word(string word, unsigned long int position, 
                                  unsigned long int size);
    
    int* find_word(string word);

private:
    
    struct NoTrie {
        NoTrie        *filhos[26]{nullptr};   //pode ser uma 'LinkedList' de ponteiros
        unsigned long  posicao;
        unsigned long  comprimento;  //se maior que zero, indica último caracter de uma palavra
    };

    int n_prefixos(NoTrie* nodo);
    void clear(NoTrie* nodo);

    NoTrie* root;
};

}  // namespace structures

#endif

structures::TrieTree::TrieTree() {
    root = new NoTrie;
    root->posicao = 0;
    root->comprimento = 0;
}

structures::TrieTree::~TrieTree() {
    clear(root);
    root = nullptr;
}

void structures::TrieTree::insert_word(string word, unsigned long int position, 
                                       unsigned long int size) {
    int tamanho = word.size();
    NoTrie* p = root;
    for (int i = 0; i < tamanho - 1; i++) {
        if (p->filhos[word[i] - 'a'] == nullptr) {
            NoTrie* newLetter = new NoTrie;
            newLetter->posicao = 0;
            newLetter->comprimento = 0;
            p->filhos[word[i] - 'a'] = newLetter;
        } 
        p = p->filhos[word[i] - 'a'];
    }
    NoTrie* lastLetter;
    
    if (p->filhos[word[tamanho-1] - 'a'] == nullptr) {
            lastLetter = new NoTrie;
            lastLetter->posicao = position;
            lastLetter->comprimento = size;
            p->filhos[word[tamanho-1] - 'a'] = lastLetter;
    } else {
        lastLetter = p->filhos[word[tamanho-1] - 'a'];
        lastLetter->posicao = position;
        lastLetter->comprimento = size;
    }
}

void structures::TrieTree::clear(NoTrie* nodo) {

    for (int i = 0; i < 26; i++) {
        if (nodo->filhos[i] != nullptr) {
            clear(nodo->filhos[i]);
            nodo->filhos[i] = nullptr;
        }
    }
    delete nodo;
}

int structures::TrieTree::n_prefixos(NoTrie* nodo) {
    int num_pref = 0;
    if (nodo != nullptr) {
        if (nodo->comprimento > 0) num_pref = 1;
    } else {
        return num_pref;
    }
    NoTrie* filho;
    for (int i = 0; i < 26; i++) {
        filho = nodo->filhos[i];
        num_pref += n_prefixos(filho);
    }
    
    return num_pref;
}

int* structures::TrieTree::find_word(string word) {
    int* dados = new int[3];
    dados[0] = 0; dados[1] = 0; dados[2] = 0;
    
    int tamanho = word.size();
    NoTrie* p = root;
    
    for (int i = 0; i < tamanho - 1; i++) {
        if (p->filhos[word[i] - 'a'] == nullptr) return dados;
        p = p->filhos[word[i] - 'a'];
    }
    
    if (p->filhos[word[tamanho-1] - 'a'] == nullptr) {
        return dados;
    } else {
        NoTrie* lastLetter = p->filhos[word[tamanho-1] - 'a'];
        dados[0] = n_prefixos(lastLetter);
        dados[1] = lastLetter->posicao;
        dados[2] = lastLetter->comprimento;
    }
    
    return dados;
}

