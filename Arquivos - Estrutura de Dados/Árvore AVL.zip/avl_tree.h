// Copyright [2019] <Guilherme Adenilson de Jesus>
#include "array_list.h"

#ifndef STRUCTURES_AVL_TREE_H
#define STRUCTURES_AVL_TREE_H

#include <cstdint>

namespace structures {

template<typename T>
class AVLTree {
public:
    ~AVLTree();

    void insert(const T& data);

    void remove(const T& data);

    bool contains(const T& data) const;

    bool empty() const;

    std::size_t size() const;

    int height() const;

    ArrayList<T> pre_order() const;

    ArrayList<T> in_order() const;

    ArrayList<T> post_order() const;

private:
    struct Node {
        T data;
        int height_;
        Node* left;
        Node* right;

        bool contains(const T& data_) const {
            if (this->data == data_) return true;
            if (data_ < this->data && this->left != nullptr) {
                return this->left->contains(data_);
            } else {
                if (data_ > this->data && this->right != nullptr) {
                    return this->right->contains(data_);
                }
            }
            return false;
        }

        void pre_order(ArrayList<T>& v) const {
            v.push_back(this->data);
            if (this->left != nullptr) this->left->pre_order(v);
            if (this->right != nullptr) this->right->pre_order(v);
        }

        void in_order(ArrayList<T>& v) const {
            if (this->left != nullptr) this->left->in_order(v);
            v.push_back(this->data);
            if (this->right != nullptr) this->right->in_order(v);
        }

        void post_order(ArrayList<T>& v) const {
            if (this->left != nullptr) this->left->post_order(v);
            if (this->right != nullptr) this->right->post_order(v);
            v.push_back(this->data);
        }

        int height() {
            return height_;
        }
    };

    int maior(int h_left, int h_right) {
        if (h_left > h_right) {
            return h_left;
        } else {
            return h_right;
        }
    }

    void rotacaoLL(Node** raiz) {
        Node* no = (*raiz)->left;
        (*raiz)->left = no->right;
        no->right = (*raiz);
        (*raiz)->height_ = maior(alt_NO((*raiz)->left),
                           alt_NO((*raiz)->right)) + 1;
        no->height_ = maior(alt_NO(no->left), alt_NO(no->right)) + 1;
        (*raiz) = no;
    }
    void rotacaoRR(Node** raiz) {
        Node* no = (*raiz)->right;
        (*raiz)->right = no->left;
        no->left = (*raiz);
        (*raiz)->height_ = maior(alt_NO((*raiz)->left),
                           alt_NO((*raiz)->right)) + 1;
        no->height_ = maior(alt_NO(no->left), alt_NO(no->right)) + 1;
        (*raiz) = no;
    }
    void rotacaoRL(Node** raiz) {
        rotacaoLL(&(*raiz)->right);
        rotacaoRR(raiz);
    }
    void rotacaoLR(Node** raiz) {
        rotacaoRR(&(*raiz)->left);
        rotacaoLL(raiz);
    }

    int alt_NO(Node* No) {
        if (No == nullptr) {
            return -1;
        } else {
            return No->height_;
        }
    }
    int fatorBalanceamento_NO(Node* raiz) {
        return abs(alt_NO(raiz->left) - alt_NO(raiz->right));
    }
    int insere_AVL(Node **raiz, const T& data_) {
        int res;
        if (*raiz == nullptr) {
            Node* novo = new Node;
            if (novo == nullptr) return 0;
            novo->data = data_;
            novo->height_ = 0;
            novo->left = nullptr;
            novo->right = nullptr;
            *raiz = novo;
            return 1;
        }
        Node* atual = *raiz;
        if (data_ < atual->data) {
            res = insere_AVL(&(atual->left), data_);
            if (res == 1) {
                if (fatorBalanceamento_NO(atual) >= 2) {
                    if (data_ < (*raiz)->left->data) {
                        rotacaoLL(raiz);
                    } else {
                        rotacaoLR(raiz);
                    }
                }
            }
        } else {
            if (data_ > atual->data) {
                res = insere_AVL(&(atual->right), data_);
                if (res == 1) {
                    if (fatorBalanceamento_NO(atual) >= 2) {
                        if ((*raiz)->right->data < data_) {
                            rotacaoRR(raiz);
                        } else {
                            rotacaoRL(raiz);
                        }
                    }
                }
            } else {
                printf("Valor duplicado\n");
                return 0;
            }
        }
        atual->height_ = maior(alt_NO(atual->left), alt_NO(atual->right))
                         + 1;
        return res;
    }
    Node* procuraMenor(Node* no) {
        Node* no1 = no;
        Node* no2 = no->left;
        while (no2 != NULL) {
            no1 = no2;
            no2 = no2->left;
        }
        return no1;
    }
    int remover_AVL(Node** raiz, const T& data_) {
        if (*raiz == nullptr) {
            printf("Valor não existe\n");
            return 0;
        }
        int res;
        if (data_ < (*raiz)->data) {
            res = remover_AVL(&(*raiz)->left, data_);
            if (res == 1) {
                if (fatorBalanceamento_NO(*raiz) >= 2) {
                    if (alt_NO((*raiz)->right->left) <=
                        alt_NO((*raiz)->right->right)) {
                        rotacaoRR(raiz);
                    } else {
                        rotacaoRL(raiz);
                    }
                }
            }
        }
        if (data_ > (*raiz)->data) {
            res = remover_AVL(&(*raiz)->right, data_);
            if (res == 1) {
                if (fatorBalanceamento_NO(*raiz) >= 2) {
                    if (alt_NO((*raiz)->left->right) <=
                        alt_NO((*raiz)->left->left)) {
                        rotacaoLL(raiz);
                    } else {
                        rotacaoLR(raiz);
                    }
                }
            }
        }
        if ((*raiz)->data == data_) {
            if (((*raiz)->left == nullptr) || (*raiz)->right == nullptr) {
                Node* aux = (*raiz);
                if ((*raiz)->left != nullptr) {
                    *raiz = (*raiz)->left;
                } else {
                    *raiz = (*raiz)->right;
                }
                delete aux;
            } else {
                Node* tmp = procuraMenor((*raiz)->right);
                (*raiz)->data = tmp->data;
                remover_AVL(&(*raiz)->right, data_);
                if (fatorBalanceamento_NO(*raiz) >= 2) {
                    if (alt_NO((*raiz)->left->right) <=
                    alt_NO((*raiz)->left->left)) {
                        rotacaoLL(raiz);
                    } else {
                        rotacaoLR(raiz);
                    }
                }
            }
            if (*raiz != nullptr)
                (*raiz)->height_ = maior(alt_NO((*raiz)->left),
                                   alt_NO((*raiz)->right)) + 1;
            return 1;
        }
        (*raiz)->height_ = maior(alt_NO((*raiz)->left),
                           alt_NO((*raiz)->right)) + 1;
        return res;
    }


    Node* root;
    std::size_t size_;
};

}  // namespace structures

#endif

template<typename T>
structures::AVLTree<T>::~AVLTree() {
    while (root != nullptr) remove(root->data);
    size_ = 0;
}

template<typename T>
void structures::AVLTree<T>::insert(const T& data) {
    insere_AVL(&root, data);
    size_++;
}

template<typename T>
void structures::AVLTree<T>::remove(const T& data) {
    if (empty()) throw std::out_of_range("Empty tree!");
    remover_AVL(&root, data);
    size_--;
}

template<typename T>
bool structures::AVLTree<T>::contains(const T& data) const {
    if (root != nullptr) {
        return root->contains(data);
    }
    return false;
}

template<typename T>
bool structures::AVLTree<T>::empty() const {
    return (size_ == 0);
}

template<typename T>
std::size_t structures::AVLTree<T>::size() const {
    return size_;
}

template<typename T>
structures::ArrayList<T> structures::AVLTree<T>::pre_order() const {
    structures::ArrayList<T> list{size()};
    if (root != nullptr) {
        root->pre_order(list);
    }
    return list;
}

template<typename T>
structures::ArrayList<T> structures::AVLTree<T>::in_order() const {
    structures::ArrayList<T> list{size()};
    if (root != nullptr) {
        root->in_order(list);
    }
    return list;
}

template<typename T>
structures::ArrayList<T> structures::AVLTree<T>::post_order() const {
    structures::ArrayList<T> list{size()};
    if (root != nullptr) {
        root->post_order(list);
    }
    return list;
}

template<typename T>
int structures::AVLTree<T>::height() const {
        if (root == nullptr) {
            return -1;
        } else {
            return root->height();
        }
}
